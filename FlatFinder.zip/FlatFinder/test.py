import math
nr_of = math.ceil(60/12.5)
print(nr_of)